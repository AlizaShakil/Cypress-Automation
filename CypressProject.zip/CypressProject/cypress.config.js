const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    setupNodeEvents(on, config) {
      // node event listeners here if needed
    },
  },
  env: {
    CYPRESS_TELEMETRY_DISABLED: true,
    CYPRESS_CRASH_REPORTS: false,
  },
});

