class ProductDetailPage {

  getProductName() {
    return cy.get('.inventory_details_name');
  }
  getProductDescription() {
    return cy.get('.inventory_details_desc');
  }
  getProductPrice() {
    return cy.get('.inventory_details_price');
  }
  clickAddToCart() {
    cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click();
  }
  clickBackToProducts() {
    cy.get('[data-test="back-to-products"]').click();
  }
}
export default ProductDetailPage;
