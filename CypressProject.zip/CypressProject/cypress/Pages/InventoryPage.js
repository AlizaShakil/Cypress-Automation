class InventoryPage {
  getTitle() {
    return cy.get('.title');
  }

  openFirstProduct() {
    cy.get('.inventory_item').first().find('a').click();
  }
}

export default InventoryPage;
