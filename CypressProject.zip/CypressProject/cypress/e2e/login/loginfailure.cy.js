describe('Login Failure Test', () => {
  it('should show error for invalid credentials', () => {
    cy.visit('https://www.saucedemo.com/');
    cy.get('#user-name').type('wrong_user');
    cy.get('#password').type('wrong_pass');
    cy.get('#login-button').click();
    cy.get('[data-test="error"]').should('be.visible');
  });
});
