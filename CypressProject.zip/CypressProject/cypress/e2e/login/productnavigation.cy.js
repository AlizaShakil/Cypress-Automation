describe('Product Navigation', () => {
  it('should open product details page', () => {
   
    cy.visit('https://www.saucedemo.com/')

    cy.get('[data-test="username"]').type('standard_user')
    cy.get('[data-test="password"]').type('secret_sauce')
    cy.get('[data-test="login-button"]').click()

    cy.contains('.inventory_item', 'Sauce Labs Backpack').click()

    cy.url().should('include', '/inventory-item.html')
    cy.get('.inventory_details_name', { timeout: 10000 }).should('be.visible')
  });
});
